import RoutePage from "./route/RoutePage";

function App() {
  return (
    <>
      <RoutePage />
    </>
  );
}

export default App;
