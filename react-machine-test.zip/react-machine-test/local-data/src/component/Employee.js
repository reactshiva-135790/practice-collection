const Employees = [
    {
      id : "1",
      name : "John",
      age : 25
    },
    {
        id : "2",
        name : "John Doe",
        age : 24
      },
      {
        id : "3",
        name : "John Doe One",
        age : 27
      },
]

export default Employees