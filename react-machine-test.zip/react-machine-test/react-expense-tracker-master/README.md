# React Expense Tracker - ReactJS Projects

### Demo - Deployed over Github Pages 
https://ayushkul.github.io/react-expense-tracker

### Full development Tutorial 
[Youtube Tutorial - The Indian Dev](https://www.youtube.com/watch?v=_UXycMmVYj0)

### Libraries used
* `styled-components`
* `react-scripts`

### Whom do I talk to? ###

* AyushK : [The Indian Dev](https://www.instagram.com/theindiandev)

### How can I appreciate this repo? ###

* By giving this repo a 🌟
* By Subscribing : [The Indian Dev](https://www.youtube.com/channel/UCbaR6YYn5VGXrR5_f-4tNsA) at Youtube
* By Following : [The Indian Dev](https://www.instagram.com/theindiandev) at Instagram

