const Results = () =>{
    return (
        <div>
            <h2>City Name : </h2>
            <div>Max Temp : </div>
            <div>Min Temp : </div>
            <div>Icon : </div>
            <div>Weather Type :</div>
        </div>
    )
}
export default Results;